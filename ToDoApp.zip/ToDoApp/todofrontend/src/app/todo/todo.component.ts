import {Component, OnInit} from '@angular/core';
import {Response} from '@angular/http';
import {Task} from './todo.model';
import {TaskService} from './todo.service';

@Component({
  selector: 'app-home',
  templateUrl: './todo.component.html'
})
export class ToDoComponent implements OnInit {

  tasks: Task[] = [];

  newTask: Task;

    constructor(private taskService: TaskService) {

    }



    ngOnInit() {
      this.getTasks();

    }

  getTasks()
      {

      this.taskService.getTasks()
      .subscribe(tasks =>
           {
              this.tasks = tasks;
              console.log(JSON.stringify(this.tasks));
          },
          (error) => console.log(error)
      );



        }

    save() {

      this.taskService.addTask (this.newTask) .subscribe(newTask =>
           {
            this.newTask = newTask;

        },
        (error) => console.log(error)
    );

    this.getTasks();
  }

    delete(task: Task) {

            this.taskService.deleteTask(this.newTask) .subscribe(newCoupon =>
                 {

                  this.newTask = new Task();
              },
              (error) => console.log(error)
          );
          this.getTasks();
        }
          update(task: Task) {

            this.taskService.updateTask(this.newTask) .subscribe(newTask =>
              {
               this.newTask = task;
               this.tasks.push(task);
           },
           (error) => console.log(error)
       );

    console.log(JSON.stringify(this.tasks));
    this.getTasks();
}
}
