import { Injectable } from '@angular/core';


export class Task {

    public id: string ;

    public taskName: string ;

    public  status: string;


  constructor() {

     }
    }
