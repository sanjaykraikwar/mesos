import {Http, Response, RequestOptions , Headers} from '@angular/http';
import 'rxjs/Rx';
import {Observable} from 'rxjs/Observable';
import {Task} from './todo.model';
import {EventEmitter, Injectable} from '@angular/core';

@Injectable()
export class TaskService {


    constructor(private http: Http  ) {}

    getTasks (): Observable<Task[]> {
      let url ='http://localhost:8081/tasks/all';
    return this.http.get(url)
                    .map(res => res.json());

    }

    addTask(task: Task): Observable<Task> {

      let url ='http://localhost:8081/tasks';
      let headers = new Headers({ 'Content-Type': 'application/json' });
      let options = new RequestOptions({ headers: headers });
      return this.http.post(url, task, options)
      .map(res =>  res.json());
  }


  deleteTask(task: Task): Observable<Task>{
    let url ='http://localhost:8081/tasks/';
      return this.http.delete(url + task.id)
          .map(
              (response: Response) => {
                  return response.json();
              }
          );
  }


  updateTask(task: Task): Observable<Task>{

    let url ='http://localhost:8081/tasks/'+ task.id;
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    return this.http.put(url, task, options)
        .map(
            (response: Response) => {
                return response.json();
            }
        );
}

}
